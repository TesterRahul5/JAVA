import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class SockPair
{
	static int sockColor(int n, int[] color) 
	{
		int pairs = 0;
		Map<Integer, Integer> map = new HashMap<>();
		for (int i = 0; i < n; i++)
		{
			if (map.containsKey(color[i]))
			{
				int count = map.get(color[i]);
				map.put(color[i], count+1);
			} 
			else 
			{
				map.put(color[i], 1);
			}
		}
		for (int i : map.values()) 
		{
			pairs = pairs + (i / 2);
		}
		return pairs;

	}

	public static void main(String args[]) 
	{
		Scanner sc = new Scanner(System.in);
		int number = sc.nextInt();
		int arr[] = new int[number];
		for (int i = 0; i < number; i++)
		{
			arr[i] = sc.nextInt();
		}
		System.out.println(sockColor(number, arr));
	}

}

