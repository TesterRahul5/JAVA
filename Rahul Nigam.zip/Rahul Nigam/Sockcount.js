
<script>

function sockCount(n, color)
{
 
    let Pairs = 0;
    let colorNum = 0;
    let SortColor = color.sort(function(a, b) 
    {
        return a - b;
    });
    for (let i = 0; i < SortColor.length; i++) 
	{
          if (SortColor[i] === colorNum) 
	  {
             continue;
          }
	 else 
	 {
            Pairs += Math.floor(((SortColor.lastIndexOf(SortColor[i]) - SortColor.indexOf(SortColor[i])) + 1) / 2);
           colorNum  = SortColor[i];
         }
       }
    return Pairs;
}

console.log(sockCount(17,[10,10,10,10,20,30,30,30,30,30,30,30,40,40,40,40,40]));

</script>
